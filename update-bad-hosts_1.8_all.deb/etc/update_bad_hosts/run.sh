#!/bin/bash

cd /etc/update_bad_hosts

./loop.sh &
